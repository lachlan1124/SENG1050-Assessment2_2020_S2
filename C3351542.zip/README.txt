STUDENT NUMBER: C3351542

Files:
index.html
style.css
xml/tempate.xml
xml/beachPackages.xml
xml/SnowPackages.xml
xml/category.xsl
images/background.jpg
images/byron.jpg
images/contentBackground.jpg
images/noosa.jpg
images/perisher.jpg
pages/About.html
pages/Contact.html
pages/holidaySuggestion.html
pages/privacy.html
pages/Terms.html

Background photos taken from https://www.pexels.com/license/

byron.jpg from https://www.smartertravel.com/uploads/2018/05/Byron-Bay-1024x683.jpg
noosa.jpg from https://assets.atdw-online.com.au/images/e5007690266bbb9ad02e8e549c097886.jpeg?rect=195%2C0%2C3115%2C2336&w=600
perisher.jpg from https://www.travelshelper.com/wp-content/uploads/2017/11/Perisher-travel-guide-Ski-Resort-in-Australia-Travel-S-Helper.jpg

